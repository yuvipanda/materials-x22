test = {   'name': 'q3_3_1',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 0 <= proportion_correct <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
