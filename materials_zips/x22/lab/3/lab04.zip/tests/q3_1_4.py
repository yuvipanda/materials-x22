test = {   'name': 'q3_1_4',
    'points': [0],
    'suites': [   {   'cases': [{'code': ">>> top_left >= 1 and top_left <= 5 # It looks like you've chosen an illegal option (not within 1-5)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
