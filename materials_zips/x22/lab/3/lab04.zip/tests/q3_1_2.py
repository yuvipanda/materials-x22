test = {   'name': 'q3_1_2',
    'points': [0],
    'suites': [   {   'cases': [{'code': ">>> bottom_right >= 1 and bottom_right <= 5 # It looks like you've chosen an illegal option (not within 1-5)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
