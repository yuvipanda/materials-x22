test = {   'name': 'q3_1_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> bottom_right >= 1 and bottom_right <= 5 # It looks like you've chosen an illegal option (not within 1-5)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bottom_right == 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
