test = {   'name': 'q1_6',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> -1 <= r <= 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> round(r,3) == 0.901\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
