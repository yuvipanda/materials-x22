test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> abs(sum(faithful_standard.column(0))) <= 1e-8\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(duration_std, 2) == 1.14\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(wait_std, 2) == 13.57 \nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
