test = {   'name': 'q3_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> round(two_minute_predicted_waiting_time, 3) == 54.934\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(five_minute_predicted_waiting_time, 3) == 87.123\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
