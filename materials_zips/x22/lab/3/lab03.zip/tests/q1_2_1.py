test = {   'name': 'q1_2_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 0.2 < outer_space_r < 0.4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(outer_space_r, 3) == .319\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
