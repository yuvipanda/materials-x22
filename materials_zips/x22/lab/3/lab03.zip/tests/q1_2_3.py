test = {   'name': 'q1_2_3',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> type(san_francisco) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> san_francisco == 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
