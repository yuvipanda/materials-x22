test = {   'name': 'q2_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 0 < one_distance < .01\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(one_distance, 6)\n0.0012229999999999999', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
