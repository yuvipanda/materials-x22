test = {   'name': 'q2_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 0 < one_distance < .01\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(one_distance, 0.001223)\nFalse', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
