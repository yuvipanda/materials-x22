test = {   'name': 'q2_1_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> np.isclose(distance_from_python('clerks.'), 0.00079838)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(distance_from_python('the godfather'), 0.001222521)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
