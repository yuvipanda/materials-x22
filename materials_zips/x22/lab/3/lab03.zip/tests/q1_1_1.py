test = {   'name': 'q1_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(stemmed_message) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> len(stemmed_message) < len('elements')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> stemmed_message\n'element'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
