test = {   'name': 'q1_1_1',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(stemmed_message) == str\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> len(stemmed_message) < len('elements')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
