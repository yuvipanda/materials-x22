test = {   'name': 'q1_0',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 0 < expected_row_sum\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> int(expected_row_sum) == 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
