test = {   'name': 'q1_1_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(count_single_stems) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> count_single_stems == 1408\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
