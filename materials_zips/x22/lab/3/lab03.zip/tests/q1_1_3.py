test = {   'name': 'q1_1_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> type(longest_uncut) == str\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
