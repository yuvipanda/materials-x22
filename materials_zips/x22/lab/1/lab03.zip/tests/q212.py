test = {   'name': 'q212',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(hello_world_components) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(hello_world_components)\n5', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> all(hello_world_components == np.array(["Hello", ",", " ", "world", "!"]))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
