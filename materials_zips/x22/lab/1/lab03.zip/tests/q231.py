test = {   'name': 'q231',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> # It looks like you're not making an array.  You shouldn't need to\n"
                                               '>>> # use .item anywhere in your solution.\n'
                                               '>>> import numpy as np\n'
                                               '>>> type(population_rounded) == np.ndarray\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> # You made an array, but it doesn't have the right numbers in it.\n>>> import numpy as np\n>>> sum(population_rounded) == 312868000000\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
