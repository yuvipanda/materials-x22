test = {   'name': 'q2_3',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> 10 <= poverty_percent <= 20\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
