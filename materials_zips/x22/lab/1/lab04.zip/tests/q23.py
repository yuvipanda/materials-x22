test = {   'name': 'q23',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # Your answer should be a number\n>>> type(mark_hurd_pay) != str\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> # Don't forget to give your answer in dollars, not millions of \n>>> # Dollars! \n>>> mark_hurd_pay != 5325\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> # Don't forget to give your answer in dollars, not millions of \n>>> # Dollars! \n>>> mark_hurd_pay == 53250000\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
