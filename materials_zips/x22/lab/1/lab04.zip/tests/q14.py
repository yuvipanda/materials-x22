test = {   'name': 'q14',
    'points': None,
    'suites': [{'cases': [{'code': '>>> print_kth_top_movie_year(4)\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
