test = {   'name': 'q24',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> convert_pay_string_to_number("$100 ") == 100000000.0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> convert_pay_string_to_number("$23 ") == 23000000.0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
