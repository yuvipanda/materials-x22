test = {   'name': 'q1_2_2_3_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> # Fill in the line that currently says\n>>> #   predicted_distance_m = ...\n>>> # in the cell above.\n>>> predicted_distance_m != ...\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Compute predicted_distance_m using the formula in the text\n'
                                               '>>> # above.  Hint: it should start with something like this:\n'
                                               '>>> #   predicted_distance_m = (1/2) * gravity_constant ...\n'
                                               '>>> round(predicted_distance_m, 5)\n'
                                               '1.17022',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> round(difference, 5)\n0.04022', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
