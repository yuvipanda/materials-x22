test = {   'name': 'q2_3_1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> # Fill in the row\n'
                                               '>>> #   time = ...\n'
                                               '>>> # with something like:\n'
                                               '>>> #   time = 4.567\n'
                                               '>>> # (except with the right number).\n'
                                               '>>> time != ...\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # Read the text above the question to see what\n>>> # time should be. \n>>> round(time, 5)\n1.2', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Fill in the row\n'
                                               '>>> #   estimated_distance_m = ...\n'
                                               '>>> # with something like:\n'
                                               '>>> #   estimated_distance_m = 4.567\n'
                                               '>>> # (except with the right number). \n'
                                               '>>> estimated_distance_m != ...\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # Note that the units are meters, but the text used\n>>> # centimeters.\n>>> estimated_distance_m != 113\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Read the text above the question to see what\n>>> # estimated_distance_m should be.\n>>> round(estimated_distance_m, 5)\n1.13',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
