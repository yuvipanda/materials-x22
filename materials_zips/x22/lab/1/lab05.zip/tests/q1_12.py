test = {   'name': 'q1_12',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': ">>> # Check your column labels and spelling\n>>> pop_by_decade.labels == ('decade', 'population')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> # The first year of the 1960's is 1960.\n>>> pop_by_decade.column(0).item(0) == 1960\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
