test = {   'name': 'q34',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> farmers_markets_without_fmid.num_columns\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> print(sorted(farmers_markets_without_fmid.labels))\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
