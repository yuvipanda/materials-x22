test = {'name': 'q11', 'points': None, 'suites': [{'cases': [{'code': '>>> new_year\n2022', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
