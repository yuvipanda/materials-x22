test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> round(age_mean, 3) == 27.228\n', 'hidden': False, 'locked': False}, {'code': '>>> round(age_sd, 3) == 5.815\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
