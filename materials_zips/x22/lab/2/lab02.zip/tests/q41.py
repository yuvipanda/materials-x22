test = {   'name': 'q41',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 3000 <= total_score <= 4000\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
