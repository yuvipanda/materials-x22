test = {   'name': 'q1_2_1',
    'points': [0],
    'suites': [{'cases': [{'code': '>>> type(largest_2010_range_date) == str\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
