test = {   'name': 'q1_2_6',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 66.6 <= feb_present_ci <= 67.3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
