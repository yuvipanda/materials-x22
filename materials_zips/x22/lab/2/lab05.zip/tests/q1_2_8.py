test = {   'name': 'q1_2_8',
    'points': [1],
    'suites': [{'cases': [{'code': '>>> type(months) == np.ndarray\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
