test = {   'name': 'q1_2_8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(months) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> comparison_results = make_array('**below**', '*above*', '*above*', '**below**', '**below**', '**below**',\n"
                                               "...                                 '**below**', '**below**', '**below**', '**below**', '**below**', '*above*')\n"
                                               '>>> np.all(comparisons == comparison_results)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
