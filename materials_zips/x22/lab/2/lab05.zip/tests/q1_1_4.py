test = {   'name': 'q1_1_4',
    'points': [1],
    'suites': [   {   'cases': [{'code': '>>> # Make sure the function outputs a string!\n>>> type(coordinates_to_region(50, 100)) == str\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
