test = {   'name': 'q2_9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(precipitation_p_val) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= precipitation_p_val <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0.015 < precipitation_p_val < .035\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
