test = {   'name': 'q2_9',
    'points': [0, 1],
    'suites': [   {   'cases': [   {'code': '>>> type(precipitation_p_val) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= precipitation_p_val <= 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
