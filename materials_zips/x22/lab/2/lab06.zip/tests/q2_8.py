test = {   'name': 'q2_8',
    'points': [0, 0],
    'suites': [   {   'cases': [   {'code': '>>> len(sampled_stats) == 5000\nFalse', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.std(sampled_stats) > 0\nFalse', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
