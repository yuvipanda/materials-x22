test = {   'name': 'q2_7',
    'points': [1],
    'suites': [{'cases': [{'code': '>>> -50 < simulate_precipitation_null() < 50\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
